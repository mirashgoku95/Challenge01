package com.JsonStringTest.JsonStringTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JsonStringTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(JsonStringTestApplication.class, args);
	}

}
