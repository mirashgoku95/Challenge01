package com.JsonStringTest.JsonStringTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsonStringTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
